package gm.projects.csci5551;

import gm.projects.csci5551.download.YahooFinance;
import gm.projects.csci5551.worker.FindOptimum;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 
 * Main class
 * 
 * @author Grant Meyers
 *
 */
public class App 
{
	//Overall work timeout in milliseconds
	private final static long WAIT_MAX_TIME = 300000;
	
	//Top level thread pool size, will each launch their own thread pools later
	private final static int THREAD_POOL_SIZE = Integer.parseInt( ((System.getProperty("thread_pool_size") == null)? "4" : System.getProperty("thread_pool_size")) );
	
	//String used to split provided symbols
	private final static String SYMBOLS_SPLIT_STRING = ",";
	
	private final static String NO_DOWNLOAD_OPTION = "no_download";
	private final static String PROVIDED_SYMBOLS_OPTION = "symbols";
	
	//Assets to run the simulation on in parallel
	
	//Slow
	//private final static String[] ASSET_SYMBOLS = {"GOOGL", "MSFT", "CVX", "AMZN", "AAPL", "YHOO"};
	
	//Medium
	private final static String[] ASSET_SYMBOLS = {"GOOGL", "AAPL"};
	
	//Fast
	//private final static String[] ASSET_SYMBOLS = {"CVX"};
	
	//Where to save temporary data
	//private final static String SAVE_FOLDER = "C:\\Logs\\";
	private final static String SAVE_FOLDER = System.getProperty("user.dir") + "\\";
	private final static String FILE_EXT = ".csv";
	
	//URL Parameters
	private final static String START_MONTH = ((System.getProperty("start_month") == null)? "0": System.getProperty("start_month"));
	private final static String END_MONTH = ((System.getProperty("end_month") == null)? "10": System.getProperty("end_month"));
	
	private final static String START_DAY = ((System.getProperty("start_day") == null)? "1": System.getProperty("start_day"));
	private final static String END_DAY = ((System.getProperty("end_day") == null)? "1": System.getProperty("end_day"));
	
	private final static String START_YEAR = ((System.getProperty("start_year") == null)? "2014": System.getProperty("start_year"));
	private final static String END_YEAR = ((System.getProperty("end_year") == null)? "2015": System.getProperty("end_year"));
	
	private final static String TIME_INTERVAL = "d";
	
	private final static double CAPITAL_FOR_INVESTMENT = 100000.0D;
	
    public static void main( String[] args ) throws Exception
    {
    	Date startDate = new Date();
        System.out.println( "Starting up @ " + startDate.getTime());
        
        String[] symbolsToProcess = null;
        
        //Optionally download files from Yahoo Finance or use pre-downloaded files.
        if(System.getProperty(NO_DOWNLOAD_OPTION) != null) {
        	//Optionally use provided Asset Symbols that are already downloaded
        	String providedAssetData = System.getProperty(PROVIDED_SYMBOLS_OPTION);
        	
        	if(providedAssetData == null || providedAssetData.isEmpty()) {
        		System.out.println("No Download Mode Specified, but no valid asset data option provided.\n");
        		System.out.println("Command Parameters should be like:\n\tjava -D" + NO_DOWNLOAD_OPTION + "=true -D" + PROVIDED_SYMBOLS_OPTION + "=GOOGL,AAPL <Rest of Command>\n");
        		System.out.println("Asset Symbol's CSV should be downloaded from Yahoo Finance and called <SYMBOL>.csv (ie GOOGL.csv) in the same directory as the .jar file.\n");
        		System.out.println("Example Yahoo URL:\n\thttp://real-chart.finance.yahoo.com/table.csv?s=GOOGL&d=10&e=1&f=2015&g=d&a=0&b=1&c=2014&ignore=.csv");
        		System.exit(-1);
        	}
        	
        	symbolsToProcess = providedAssetData.split(SYMBOLS_SPLIT_STRING);
        	
        	System.out.println("Using provided symbols: ");
        	for(String curSymbol : symbolsToProcess) {
        		System.out.println("\t" + curSymbol);
        	}
        } else {
        	//Optionally use provided Asset Symbols
        	String providedAssetData = System.getProperty(PROVIDED_SYMBOLS_OPTION);
        	
        	if(providedAssetData == null || providedAssetData.isEmpty()) {
            	symbolsToProcess = ASSET_SYMBOLS;
        	} else {
            	symbolsToProcess = providedAssetData.split(SYMBOLS_SPLIT_STRING);
        	}
        	
            //Download and save data
            for(String assetSymbol : symbolsToProcess) {
                System.out.println( "Loading Yahoo Finance Source, for symbol: " + assetSymbol );
                
                YahooFinance curAsset = new YahooFinance();
                Map<String, Object> settings = getStaticOptions();
                settings.put(YahooFinance.SYMBOL_KEY, assetSymbol);
                
                String fileName = SAVE_FOLDER + assetSymbol + FILE_EXT;
                curAsset.setFileName(fileName);
                settings.put(YahooFinance.FILENAME_KEY, fileName);
                
                curAsset.setSettings(settings);
                
                if(!curAsset.downloadHistory()) {
                	System.out.println("Failed to download information for: " + assetSymbol);
                }
            }
        }
        
        //////////////////////Start Top Level Parallel Searches//////////////////////
        ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        
        //Process data
        for(String assetSymbol : symbolsToProcess) {
            String fileName = SAVE_FOLDER + assetSymbol + FILE_EXT;
            executorService.execute(new FindOptimum(fileName, assetSymbol, CAPITAL_FOR_INVESTMENT));
        }
        
        //Signal the executor service that all tasks have been submitted.
        executorService.shutdown();
        
        //Wait for all tasks to complete up to WAIT_MAX_TIME / 1000 seconds.			
        if(!executorService.awaitTermination(WAIT_MAX_TIME, TimeUnit.MILLISECONDS)) {
        	System.out.println("Executor service was forced to shutdown, may need to adjust timeout up.");
        	executorService.shutdownNow();
        }
        
        //////////////////////End Top Level Parallel Searches//////////////////////
        
        //Runtime statistics
        Date endDate = new Date();
        System.out.println( "Finished up @ " + endDate.getTime());
        System.out.println( "Took " + (endDate.getTime() - startDate.getTime()) + " milliseconds");
        
        //This speeds up the executor services clean-up
        System.exit(0);
    }
    
    /**
     * Function to load standard options set as final static in the beginning of the class.
     * 
     * @return Map of static settings for Downloading from Yahoo Finance.
     */
    private static Map<String, Object> getStaticOptions() {
    	HashMap<String, Object> ret = new HashMap<String, Object>();

    	ret.put(YahooFinance.START_MONTH_KEY, START_MONTH);
    	ret.put(YahooFinance.END_MONTH_KEY, END_MONTH);
    	
    	ret.put(YahooFinance.START_DAY_KEY, START_DAY);
    	ret.put(YahooFinance.END_DAY_KEY, END_DAY);
    	
    	ret.put(YahooFinance.START_YEAR_KEY, START_YEAR);
    	ret.put(YahooFinance.END_YEAR_KEY, END_YEAR);
    	
    	ret.put(YahooFinance.TIME_INTERVAL_KEY, TIME_INTERVAL);
    	    	
    	return ret;
    }
}
