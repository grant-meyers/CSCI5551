package gm.projects.csci5551.calculate;

import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.commons.math3.stat.regression.SimpleRegression;

/**
 * Class for calculating profit generated from making asset purchases when the
 * regression deviation is below a set limit and selling when the regression
 * deviation is above a set price with a known initial capital, actual price,
 * and regression model for asset price.
 * 
 * @author Grant Meyers
 *
 */
public class ProfitForParameters {
	// Cost to do 1 buy and 1 sell
	private final static double TRANSACTION_COST = 18.0D;

	// Count how many times the asset is bought or sold.
	private double buySellCycleCount = 0.0D;
	// Concurrently accessible read-only set of asset prices
	private ConcurrentLinkedQueue<Double> assetPrices = null;
	// Model to calculate deviation
	private SimpleRegression simpleRegression = null;

	public ProfitForParameters(ConcurrentLinkedQueue<Double> assetPrices,
			SimpleRegression simpleRegression) {
		this.assetPrices = assetPrices;
		this.simpleRegression = simpleRegression;
	}

	/**
	 * Function to calculate profit from buying and selling an asset at set min
	 * deviation from the regression model of the price.
	 * 
	 * @param buyDeviation
	 *            minimum deviation to start buying the asset at
	 * @param sellDeviation
	 *            minimum deviation to start selling the asset at
	 * @param capital
	 *            money to invest
	 * @return double profit generated with these parameters
	 */
	public double getProfitForParameters(double buyDeviation,
			double sellDeviation, double capital) {
		double dateOffset = 0.0D;
		double ret = 0.0D;
		boolean stockOwned = false;
		double lastPurchasePrice = 0.0D;
		double currentCapital = capital;

		buySellCycleCount = 0.0D;
		Iterator<Double> iter = assetPrices.iterator();

		// Iterate over the actual asset prices
		while (iter.hasNext()) {
			double actualValue = iter.next().doubleValue();
			double predictionValue = simpleRegression.predict(dateOffset);
			double deviation = predictionValue - actualValue;

			// Check for selling point
			if (stockOwned) {
				// Make the sale since the price is so high
				if (deviation < 0.0D
						&& Math.abs(deviation) >= Math.abs(sellDeviation)) {
					stockOwned = false;

					// Check how many full shares were purchased.
					double sharesBought = Math.floor(currentCapital
							/ lastPurchasePrice);
					ret += (sharesBought * actualValue)
							- (sharesBought * lastPurchasePrice)
							- TRANSACTION_COST;

					// Reinvest profits for next purchase
					currentCapital = (currentCapital - (sharesBought * lastPurchasePrice))
							+ sharesBought * actualValue;
					currentCapital -= TRANSACTION_COST;

					buySellCycleCount++;
				}
			} else {
				// Make a purchase since the price is so cheap
				if (deviation > 0.0D
						&& Math.abs(deviation) >= Math.abs(buyDeviation)) {
					stockOwned = true;
					lastPurchasePrice = Math.abs(actualValue);

					buySellCycleCount++;
				}
			}

			dateOffset++;
		}

		return ret;
	}

	/**
	 * Getter for buy sell asset cycle count, answer is divided by two as each
	 * buy and sell is counted indvidually.
	 * 
	 * @return double buy sell asset cycle count
	 */
	public double getLastBuySellCycleCount() {
		return buySellCycleCount / 2.0D;
	}
}
