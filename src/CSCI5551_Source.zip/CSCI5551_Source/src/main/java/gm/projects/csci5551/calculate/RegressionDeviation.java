package gm.projects.csci5551.calculate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import org.apache.commons.math3.stat.regression.RegressionResults;
import org.apache.commons.math3.stat.regression.SimpleRegression;

public class RegressionDeviation {
	private final static String CSV_SPLIT = ",";
	private final static String DATE_FORMAT = "yyyy-MM-dd";
	
	private ArrayDeque<String> fileContents = null;
	private SimpleRegression regressionModel = null;
	private Date startDate = null;
	private Date endDate = null;

	//Positive Deviation Numbers
	private double largestPositiveDeviation = 0.0D;
	private double deviationDatePositive = 0.0D;
	private double deviationExpectedValPositive = 0.0D;
	private double deviationActualValPositive = 0.0D;
	
	//Negative Deviation Numbers
	private double largestNegativeDeviation = 0.0D;
	private double deviationDateNegative = 0.0D;
	private double deviationExpectedValNegative = 0.0D;
	private double deviationActualValNegative = 0.0D;
	
	/**
	 * Getter for largest positive regression deviation.
	 * @return the largestPositiveDeviation
	 */
	public double getLargestPositiveDeviation() {
		return largestPositiveDeviation;
	}

	/**
	 * Getter for largest negative regression deviation.
	 * @return the largestNegativeDeviation
	 */
	public double getLargestNegativeDeviation() {
		return largestNegativeDeviation;
	}

	public RegressionDeviation() {
		regressionModel = new SimpleRegression(true);
	}
	
	public ArrayDeque<String> getAssetPrices() {
		return fileContents;
	}
	
	public RegressionResults getRegression() {
		return regressionModel.regress();
	}
	
	public SimpleRegression getRegressionModel() {
		return regressionModel;
	}
	
	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}
	
	public long getDataPoints() {
		return regressionModel.getN();
	}
	
	/**
	 * Function to find the search space.<br>
	 * <br>
	 * Largest positive deviation from regression model.<br>
	 * Largest negative deviation from regression model.
	 */
	public void findLargestDeviations() {
		double dateOffset = 0.0D;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		Iterator<String> iter = fileContents.iterator();
		
		//Iterate over the content of the CSV file
		while (iter.hasNext()) {
			String actualStringValue = iter.next().split(CSV_SPLIT)[6];
			
			//Print out each entry being used in the regression model.
			//System.out.println("Checking value: " + actualStringValue);
			
			double actualValue = Double.parseDouble(actualStringValue);
			double predictionValue = regressionModel.predict(dateOffset);
			double deviation = predictionValue - actualValue;
			
			//Find largest positive deviation from the regression line.
			//This is the maximum selling point.
			if(deviation > 0.0D && deviation > largestPositiveDeviation) {
				largestPositiveDeviation = deviation;
				deviationDatePositive = dateOffset;
				deviationExpectedValPositive = predictionValue;
				deviationActualValPositive = actualValue;
			}
			
			//Find the largest negative deviation from the regression line.
			//This is the minimum buying point.
			if(deviation < 0.0D && deviation < largestNegativeDeviation) {
				largestNegativeDeviation = deviation;
				deviationDateNegative = dateOffset;
				deviationExpectedValNegative = predictionValue;
				deviationActualValNegative = actualValue;
			}
			
			dateOffset++;
		}

		//Calculate date of largest positive deviation
		//calendar.add(Calendar.DAY_OF_YEAR, (int)(deviationDatePositive));
		
		//Statistics about regression developed from data.
		//System.out.println("Greatest Positive Deviation Date: " + deviationDatePositive + " days after start date, on: " + calendar.getTime());
		//System.out.println("Greatest Positive Deviation Amount: " + largestPositiveDeviation + ".\n\tExpected: " + deviationExpectedValPositive + " Actual: " + deviationActualValPositive);

		//Undo adjustment for days to Positive deviation date
		//calendar.add(Calendar.DAY_OF_YEAR, (int)(-1.0D * deviationDatePositive));
		
		//Calculate date of largest negative deviation.
		//calendar.add(Calendar.DAY_OF_YEAR, (int)(deviationDateNegative));
		
		//Statistics about regression developed from data.
		//System.out.println("Greatest Negative Deviation Date: " + deviationDateNegative + " days after start date, on: " + calendar.getTime());
		//System.out.println("Greatest Negative Deviation Amount: " + largestNegativeDeviation + ".\n\tExpected: " + deviationExpectedValNegative + " Actual: " + deviationActualValNegative);
		
		//System.out.println("Overall direction of Asset price is: " + ((regressionModel.getSlope() > 0.0D)? "Positive." : "Negative."));
	}
	
	/**
	 * Function to load a CSV file and get the start + end dates.
	 * 
	 * @param fileName String absolute path to CSV formatted data file
	 * @throws IOException thrown if there is a problem accessing or reading file
	 */
	public void loadCSVDataSourceFile(String fileName) throws IOException {
		fileContents = new ArrayDeque<String>();
		
		BufferedReader bufferedReader = null;
		String curLine = "";
		String lastDateEntry = "";
		double dateOffset = 0.0D;

		DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		
		try {
			bufferedReader = new BufferedReader(new FileReader(fileName));
			
			//First line is column information and not source data.
			curLine = bufferedReader.readLine();
			
			//Column Headers info
			/*String[] columnTitles = curLine.split(CSV_SPLIT);
			for(int i=0; i<columnTitles.length; i++) {
				System.out.println("Column: " + i + " Title: " + columnTitles[i]);
			}*/
			
			//Invert the order of entries in the file, as the file is in descending date order.
			while ((curLine = bufferedReader.readLine()) != null) {
				fileContents.addFirst(curLine);
			}
			bufferedReader.close();
			bufferedReader = null;
			
			Iterator<String> iter = fileContents.iterator();
			while (iter.hasNext()) {
				String[] columns = iter.next().split(CSV_SPLIT);

				//Retrieve end date
				if(dateOffset == 0) {
					startDate = dateFormat.parse(columns[0]);					
					
					//Start date info
					System.out.println("Starting '" + fileName + "' Search Date set to: " + startDate);
				}
				
				//Load data into regression model
				regressionModel.addData(dateOffset, Double.parseDouble(columns[4]));
				lastDateEntry = columns[0];				
				dateOffset++;
			}

			endDate = dateFormat.parse(lastDateEntry);
			
			//End date info
			System.out.println("Ending '" + fileName + "' Search Date set to: " + endDate);
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			if(bufferedReader != null) {
				bufferedReader.close();
			}
		}
	}
}
