package gm.projects.csci5551.download;

import java.util.HashMap;
import java.util.Map;

/**
 * Base class for downloading an asset's price history into a CSV file.
 * 
 * @author Grant Meyers
 *
 */
public abstract class CSVHistoryFile implements DownloadHistory {
	private final static String FILE_FORMAT = "CSV";
	
	private Map<String, Object> settings =  new HashMap<String, Object>();
	private String assetSymbol = null;
	
	public CSVHistoryFile() {}

	public void clearSettings() {
		settings = null;
	}
	
	public Map<String, Object> getSettings() {
		return settings;
	}

	public void setSettings(Map<String, Object> settings) {
		if(this.settings == null) {
			this.settings = new HashMap<String, Object>();
		}
		this.settings.putAll(settings);
	}
	
	/**
	 * Getter for this instance's asset symbol.
	 * 
	 * @return String asset symbol.
	 */
	public String getAssetSymbol() {
		return assetSymbol;
	}
	
	/**
	 * Getter for this instance's saving file format.<br><br>
	 * Will always be "CSV".
	 * 
	 * @return String file format.
	 */
	public String getFileFormat() {
		return FILE_FORMAT;
	}

	public abstract boolean validateSettings() throws IllegalStateException;
	public abstract boolean downloadHistory() throws Exception;
	
	/**
	 * Setter for this instance's asset symbol to lookup and save data about.
	 * 
	 * @param assetSymbol String new Asset Symbol
	 */
	protected abstract void setAssetSymbol(String assetSymbol);
	
	/**
	 * Function to give the absolute path to a file to save the CSV asset data into.
	 * 
	 * @param fileName String to attempt to write data to.
	 */
	protected abstract void setFileName(String fileName);

}
