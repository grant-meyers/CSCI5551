package gm.projects.csci5551.download;

import java.util.Map;

/**
 * Interface specifying the requirements for a class that will allow for
 * Downloading an Asset's price history.
 * 
 * @author Grant Meyers
 *
 */
public interface DownloadHistory {

	/**
	 * Function to reset this instance's settings.
	 */
	void clearSettings();
	
	/**
	 * Getter for this instance's settings map.<br>
	 * <br>
	 * 
	 * null if no settings map has been set.
	 * 
	 * @return settings map.
	 */
	Map<String, Object> getSettings();

	/**
	 * Setter for this instance's settings map.
	 * 
	 * @param settings
	 *            new settings map.
	 */
	void setSettings(Map<String, Object> settings);

	/**
	 * Function to validate if provided settings map contains sufficient
	 * information.
	 * 
	 * @return true if settings are sufficient to use
	 *         {@link DownloadHistory#downloadHistory()}, false otherwise.
	 * @throws IllegalStateException
	 *             thrown if the settings map is null or otherwise invalid
	 */
	boolean validateSettings() throws IllegalStateException;

	/**
	 * Function to download a unit of history data. Uses settings map for
	 * specifics of what to do.
	 * 
	 * @return true if download was successful, false if there was a failure.
	 * @throws IllegalStateException thrown if there is an error trying to download the Asset info.
	 */
	boolean downloadHistory() throws Exception;
}
