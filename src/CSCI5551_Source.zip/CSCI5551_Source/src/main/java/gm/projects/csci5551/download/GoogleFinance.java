package gm.projects.csci5551.download;

import java.io.File;
import java.net.URL;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;

/**
 * Class to download Asset symbol data to a CSV file from Google Finance.
 * 
 * @author Grant Meyers
 *
 */
public class GoogleFinance extends InternetCSVHistoryFile {
	private final static String PATH_KEY_MODE = "DYNAMIC";
	private final static String URL_BASIC_PATTERN = "http://www.google.com/finance/historical?q=NASDAQ%3A{0}&output=csv";
	
	private String assetSymbol = null;
	private String writeFileName = null;
	
	public GoogleFinance() {
		Map<String, Object> settingsMap = getSettings();

		settingsMap.put(GoogleFinance.URL_SOURCE_KEY, URL_BASIC_PATTERN);
		settingsMap.put(GoogleFinance.URL_ABSOLUTE_PATH_KEY, PATH_KEY_MODE);
	}
	
	@Override
	public boolean downloadHistory() throws Exception {
		Map<String, Object> settingsMap = getSettings();
				
		if(!validateSettings()) {
			return false;
		}
		
		String fullURL = (String)settingsMap.get(GoogleFinance.URL_SOURCE_KEY);
		
		if(!this.isURLAbsolutePath) {
			MessageFormat.format(fullURL, new Object[]{assetSymbol});
		}
		
		URL googleFinanceURL = new URL(fullURL);
		File writeLocation = new File(writeFileName);
		
		FileUtils.copyURLToFile(googleFinanceURL, writeLocation);
		
		return true;
	}

	@Override
	protected void setAssetSymbol(String assetSymbol) {
		this.assetSymbol = assetSymbol;
	}

	@Override
	protected void setFileName(String fileName) {
		writeFileName = fileName;
	}
}
