package gm.projects.csci5551.download;

import java.util.Map;

/**
 * Base class for downloading an asset's price history from the Internet into a CSV file.
 * 
 * @author Grant Meyers
 *
 */
public abstract class InternetCSVHistoryFile extends CSVHistoryFile {
	public final static String URL_SOURCE_KEY = "URL";
	public final static String FILENAME_KEY = "FILENAME";
	public final static String SYMBOL_KEY = "SYMBOL";
	public final static String URL_ABSOLUTE_PATH_KEY = "URL_ABSOLUTE_PATH";
	
	public final static String START_MONTH_KEY = "START_MONTH";
	public final static String END_MONTH_KEY = "END_MONTH";
	
	public final static String START_DAY_KEY = "START_DAY";
	public final static String END_DAY_KEY = "END_DAY";
	
	public final static String START_YEAR_KEY = "START_YEAR";
	public final static String END_YEAR_KEY = "END_YEAR";

	public final static String TIME_INTERVAL_KEY = "TIME_INTERVAL";
	public final static String TIME_INTERVAL_VAL = "d";
	
	
	public final static String FILE_FORMAT_KEY = "FILE_FORMAT";
	public final static String FILE_FORMAT_VAL = ".csv";
	
	private final static String ABSOLUTE_URL = "ABSOLUTE";
	private final static String FORMATTER_PATTERN = "{0}";

	protected boolean isURLAbsolutePath = true;
	
	@Override
	public boolean validateSettings() throws IllegalStateException {
		Map<String, Object> settingsMap = getSettings();
		
		if(settingsMap == null) {
			throw new IllegalStateException("No Settings Map to validate.");
		}
		
		/**
		 * Any extra validation of settings would go here.
		 * 
		 * I'm just checking for null entries and appropriate requirements based on URL_ABSOLUTE_PATH_KEY.
		 */
		
		Object urlVal = settingsMap.get(URL_SOURCE_KEY);
		if(urlVal == null || ((String)urlVal).isEmpty()) {
			return false;
		}

		Object assetSymbolVal = settingsMap.get(SYMBOL_KEY);
		if(assetSymbolVal == null || ((String)assetSymbolVal).isEmpty()) {
			return false;
		} else {
			setAssetSymbol((String)assetSymbolVal);
		}

		Object saveFilenameVal = settingsMap.get(FILENAME_KEY);
		if(saveFilenameVal == null || ((String)saveFilenameVal).isEmpty()) {
			return false;
		}
		
		Object urlAbsolutePathRaw = settingsMap.get(URL_ABSOLUTE_PATH_KEY);
		
		if(urlAbsolutePathRaw == null) {
			return false;
		} else {
			String urlAbsolutePath = (String)urlAbsolutePathRaw;
			
			if(urlAbsolutePath.toUpperCase().contains(ABSOLUTE_URL)) {
				isURLAbsolutePath = true;
				
				if(!urlAbsolutePath.toUpperCase().contains(((String)assetSymbolVal).toUpperCase())) {
					return false;
				}
			} else {
				isURLAbsolutePath = false;
				
				if(!urlAbsolutePath.contains(FORMATTER_PATTERN)) {
					return false;
				}
			}
		}
		
		return true;
	}
	
}
