package gm.projects.csci5551.download;

import java.io.File;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;

/**
 * Class to download Asset symbol data to a CSV file from Yahoo Finance.
 * 
 * @author Grant Meyers
 *
 */
public class YahooFinance extends InternetCSVHistoryFile {
	private final static String PATH_KEY_MODE = "DYNAMIC";
	
	
	/**
	 * Format is:
	 * 	http://real-chart.finance.yahoo.com/table.csv?
	 * s=<Stock Symbol>
	 * &d=<End Month>
	 * &e=<End Day>
	 * &f=<End Year>
	 * &g=<Daily / Weekly / Monthly>
	 * &a=<Start Month>
	 * &b=<Start Day>
	 * &c=<Start Year>
	 * &ignore=<file type>
	 */
	private final static String URL_BASIC_PATTERN = "http://real-chart.finance.yahoo.com/table.csv?s={0}&d={1}&e={2}&f={3}&g={4}&a={5}&b={6}&c={7}&ignore={8}";
	
	private String assetSymbol = null;
	private String writeFileName = null;
	
	public YahooFinance() {
		Map<String, Object> settingsMap = getSettings();

		settingsMap.put(YahooFinance.URL_SOURCE_KEY, URL_BASIC_PATTERN);
		settingsMap.put(YahooFinance.URL_ABSOLUTE_PATH_KEY, PATH_KEY_MODE);
		settingsMap.put(YahooFinance.URL_ABSOLUTE_PATH_KEY, URL_BASIC_PATTERN);
		settingsMap.put(YahooFinance.FILE_FORMAT_KEY, YahooFinance.FILE_FORMAT_VAL);
	}
	
	@Override
	public boolean downloadHistory() throws Exception {
		Map<String, Object> settingsMap = getSettings();
				
		if(!validateSettings()) {
			return false;
		}
		
		String fullURL = (String)settingsMap.get(YahooFinance.URL_SOURCE_KEY);
		
		if(!this.isURLAbsolutePath) {
			fullURL = MessageFormat.format(fullURL, getMessageFormatValues());
		}
		
		System.out.println("Accessing URL: " + fullURL);
		
		//Print loaded settings.
		/*for(Entry<String, Object> setting : settingsMap.entrySet()) {
			System.out.println("Setting: " + setting.getKey() + " Value: " + setting.getValue());
		}*/
		
		URL yahooFinanceURL = new URL(fullURL);
		File writeLocation = new File(writeFileName);
		
		FileUtils.copyURLToFile(yahooFinanceURL, writeLocation);
		
		System.out.println("Saved file to: " + writeFileName);
		
		return true;
	}
	
	private Object[] getMessageFormatValues() {
		Map<String, Object> settingsMap = getSettings();
		ArrayList<Object> ret = new ArrayList<Object>();

		//Formatter entry {0}
		ret.add(assetSymbol);
		
		//Formatter entry {1}
		ret.add(settingsMap.get(YahooFinance.END_MONTH_KEY));
		
		//Formatter entry {2}
		ret.add(settingsMap.get(YahooFinance.END_DAY_KEY));
		
		//Formatter entry {3}
		ret.add(settingsMap.get(YahooFinance.END_YEAR_KEY));
		
		//Formatter entry {4}
		ret.add(settingsMap.get(YahooFinance.TIME_INTERVAL_KEY));
		
		//Formatter entry {5}
		ret.add(settingsMap.get(YahooFinance.START_MONTH_KEY));
		
		//Formatter entry {6}
		ret.add(settingsMap.get(YahooFinance.START_DAY_KEY));
		
		//Formatter entry {7}
		ret.add(settingsMap.get(YahooFinance.START_YEAR_KEY));
		
		//Formatter entry {8}
		ret.add(settingsMap.get(YahooFinance.FILE_FORMAT_KEY));
		
		return ret.toArray();
	}

	@Override
	protected void setAssetSymbol(String assetSymbol) {
		this.assetSymbol = assetSymbol;
	}

	@Override
	public void setFileName(String fileName) {
		writeFileName = fileName;
	}
}
