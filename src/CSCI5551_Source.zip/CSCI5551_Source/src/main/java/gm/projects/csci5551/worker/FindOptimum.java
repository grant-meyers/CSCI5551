package gm.projects.csci5551.worker;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import gm.projects.csci5551.calculate.RegressionDeviation;

public class FindOptimum implements Runnable {
	// CSV format required
	private final static String CSV_SPLIT = ",";

	// Work timeout in milliseconds
	private final static long WAIT_MAX_TIME = 240000;

	// Needs to be an integer greater than 0, such that each partition can be
	// assigned to a new thread.
	private final static int PARTITIONS_COUNT = Integer.parseInt( ((System.getProperty("partitions_count") == null)? "4" : System.getProperty("partitions_count")) );

	// Create PARTITIONS_COUNT * PARTITIONS_COUNT children threads to do work,
	// one for each possible 2 set of sell range and buy range.
	//private final static int SUB_THREAD_POOL_SIZE = PARTITIONS_COUNT * PARTITIONS_COUNT;
	private final static int SUB_THREAD_POOL_SIZE = Integer.parseInt( ((System.getProperty("sub_thread_pool_size") == null)? "8" : System.getProperty("sub_thread_pool_size")) );

	// Area to stay away from regression line, too close and you'll end up with
	// crazy numbers making cents of profit thousands of times.
	private final static double REGRESSION_BUFFER_SPACE = 5.0D;

	private String symbol = null;
	private String fileName = null;
	private double capital = 0.0D;
	private double bestProfit = 0.0D;
	private double bestBuyPrice = 0.0D;
	private double bestSellPrice = 0.0D;
	private double bestBuySellCycleCount = 0.0D;

	public FindOptimum(String fileName, String symbol, double capital) {
		this.fileName = fileName;
		this.symbol = symbol;
		this.capital = capital;
	}

	/**
	 * Generate search tasks to find optimum buy / sell deviations with in set
	 * range, then combine the results to find the best overall.
	 */
	public void run() {
		System.out.println(this.getClass().getName() + " Running on Thread: "
				+ Thread.currentThread().getId());

		ArrayList<FindOptimumInRange> optimizedSearches = new ArrayList<FindOptimumInRange>();
		RegressionDeviation regressionDeviation = new RegressionDeviation();

		try {
			regressionDeviation.loadCSVDataSourceFile(fileName);
			regressionDeviation.findLargestDeviations();

			double positiveSearchWidth = regressionDeviation.getLargestPositiveDeviation() - REGRESSION_BUFFER_SPACE;
			double perWorkerPositiveSearchWidth = positiveSearchWidth / PARTITIONS_COUNT;

			double negativeSearchWidth = regressionDeviation.getLargestNegativeDeviation() + REGRESSION_BUFFER_SPACE;
			double perWorkerNegativeSearchWidth = negativeSearchWidth / PARTITIONS_COUNT;

			ExecutorService executorService = Executors
					.newFixedThreadPool(SUB_THREAD_POOL_SIZE);

			// Group work for each search range.
			for (int i = 0; i < PARTITIONS_COUNT; i++) {
				double curMaxSell = positiveSearchWidth - i * perWorkerPositiveSearchWidth;
				double curMinSell = positiveSearchWidth - (i + 1) * perWorkerPositiveSearchWidth;

				for (int j = 0; j < PARTITIONS_COUNT; j++) {
					double curMaxBuy = negativeSearchWidth - (j + 1) * perWorkerNegativeSearchWidth;
					double curMinBuy = negativeSearchWidth - j * perWorkerNegativeSearchWidth;

					// Print search ranges
					// System.out.printf("Running Optimum Search with Regression Deviations of:\n\t curMaxBuy: %f curMinBuy: %f curMaxSell: %f curMinSell: %f \n\n",
					// curMaxBuy, curMinBuy, curMaxSell, curMinSell);

					FindOptimumInRange searchRange = new FindOptimumInRange(
							curMaxBuy,
							curMinBuy,
							curMaxSell,
							curMinSell,
							capital,
							getAssetPrices(regressionDeviation.getAssetPrices()),
							regressionDeviation.getRegressionModel());
					optimizedSearches.add(searchRange);
					executorService.execute(searchRange);
				}
			}

			// Signal the executor service that all tasks have been submitted.
			executorService.shutdown();

			// Wait for all tasks to complete up to 60 seconds.
			if(!executorService.awaitTermination(WAIT_MAX_TIME, TimeUnit.MILLISECONDS)) {
				executorService.shutdownNow();
			}

			// Find best profit producing range
			for (FindOptimumInRange searchRange : optimizedSearches) {
				if (searchRange.getBestProfit() > bestProfit) {
					bestProfit = searchRange.getBestProfit();
					bestBuyPrice = searchRange.getBestBuyPrice();
					bestSellPrice = searchRange.getBestSellPrice();
					bestBuySellCycleCount = searchRange.getBuySellCycleCount();
				}
			}

			// System.out.println("Best profit for: " + symbol + " is: " +
			// bestProfit + " generated from Buy @ " + bestBuyPrice + " Sell @ "
			// + bestSellPrice + " with Buy / Sell Cycle Count: " +
			// bestBuySellCycleCount);
			System.out.printf("Best profit for: %s is: $%.2f generated from Buy @ Deviation from Regression of: $%.2f Sell @ Deviation from Regression of: $%.2f with Buy / Sell Cycle Count: %.1f\n",
							symbol, bestProfit, bestBuyPrice, bestSellPrice,
							bestBuySellCycleCount);

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Load CSV data lines (including asset prices) into concurrently available data structure.
	 * 
	 * @param rawAssetPrices CSV data lines
	 * @return concurrently available asset prices
	 */
	private ConcurrentLinkedQueue<Double> getAssetPrices(
			ArrayDeque<String> rawAssetPrices) {
		ConcurrentLinkedQueue<Double> ret = new ConcurrentLinkedQueue<Double>();

		Iterator<String> iter = rawAssetPrices.iterator();

		// Iterate over the content of the CSV file
		while (iter.hasNext()) {
			String actualStringValue = iter.next().split(CSV_SPLIT)[6];

			double actualValue = Double.parseDouble(actualStringValue);
			ret.add(actualValue);
		}
		return ret;
	}

}
