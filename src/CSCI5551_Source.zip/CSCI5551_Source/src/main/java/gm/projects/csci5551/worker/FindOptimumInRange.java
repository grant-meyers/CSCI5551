package gm.projects.csci5551.worker;

import gm.projects.csci5551.calculate.ProfitForParameters;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.commons.math3.stat.regression.SimpleRegression;

public class FindOptimumInRange implements Runnable {

	// Adjust accuracy and therefore work to be done during searches. Smaller
	// number is more work, less than 0.01D isn't realistic as most assets do
	// not sell for more accurate price than a penny.
	private final static double STEP_SIZE = Double.parseDouble( ((System.getProperty("step_size") == null)? "0.05" : System.getProperty("step_size")) );

	// Search space parameters
	private double capital = 0.0D;
	private double buyMax = 0.0D;
	private double buyMin = 0.0D;
	private double sellMax = 0.0D;
	private double sellMin = 0.0D;
	private ProfitForParameters profitTester = null;

	// Calculated quantities
	private double bestProfit = 0.0D;
	private double bestBuyPrice = 0.0D;
	private double bestSellPrice = 0.0D;
	private double buySellCycleCount = 0.0D;

	/**
	 * Getter for highest profit buy and sell cycle count, calculated from
	 * provided parameters.<br>
	 * <br>
	 * 
	 * Updated via run() call.
	 * 
	 * @return the buySellCycleCount
	 */
	public double getBuySellCycleCount() {
		return buySellCycleCount;
	}

	/**
	 * Getter for highest profit buy price, calculated from provided parameters.<br>
	 * <br>
	 * 
	 * Updated via run() call.
	 * 
	 * @return the bestBuyPrice
	 */
	public double getBestBuyPrice() {
		return bestBuyPrice;
	}

	/**
	 * Getter for highest profit sell price, calculated from provided
	 * parameters.<br>
	 * <br>
	 * 
	 * Updated via run() call.
	 * 
	 * @return the bestSellPrice
	 */
	public double getBestSellPrice() {
		return bestSellPrice;
	}

	/**
	 * Getter for profit from provided parameters.<br>
	 * <br>
	 * 
	 * Updated via run() call.
	 * 
	 * @return the bestProfit
	 */
	public double getBestProfit() {
		return bestProfit;
	}

	public FindOptimumInRange(double buyMax, double buyMin, double sellMax,
			double sellMin, double capital,
			ConcurrentLinkedQueue<Double> assetPrices,
			SimpleRegression simpleRegression) {
		this.buyMax = buyMax;
		this.buyMin = buyMin;
		this.sellMax = sellMax;
		this.sellMin = sellMin;
		this.capital = capital;

		this.profitTester = new ProfitForParameters(assetPrices,
				simpleRegression);
	}

	/**
	 * Search for optimum buy / sell deviations with in set range
	 */
	public void run() {
		System.out.println("\t\t" + this.getClass().getName()
				+ " Running on Thread: " + Thread.currentThread().getId());

		double curBuyTestPrice = buyMin;
		double curSellTestPrice = sellMin;

		// Test all possible selections of buy deviations
		while (curBuyTestPrice <= buyMax) {

			// Test all possible selections of sell deviations
			while (curSellTestPrice <= sellMax) {

				// Get profit at current range
				double profit = profitTester.getProfitForParameters(
						curBuyTestPrice, curSellTestPrice, capital);

				// See each test.
				// //////////////////Careful - A LOT of
				// entries////////////////////
				// System.out.println("Capital: " + capital + " Profit: " +
				// profit + " with buy @ " + curBuyTestPrice + " with sell @ " +
				// curSellTestPrice + " Buy/Sell Cycles: " +
				// profitTester.getLastBuySellCycleCount());

				if (profit > bestProfit) {
					bestProfit = profit;
					bestBuyPrice = curBuyTestPrice;
					bestSellPrice = curSellTestPrice;
					buySellCycleCount = profitTester.getLastBuySellCycleCount();
				}
				curSellTestPrice += STEP_SIZE;
			}

			curSellTestPrice = sellMin;
			curBuyTestPrice += STEP_SIZE;
		}
	}

}
